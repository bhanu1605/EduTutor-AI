
import streamlit as st
from streamlit_option_menu import option_menu

# Initialize Session State
if 'user_role' not in st.session_state:
    st.session_state.user_role = None
if 'is_logged_in' not in st.session_state:
    st.session_state.is_logged_in = False

def login_page():
    st.title("EduTutor AI Login")
    login_method = st.radio("Login Method", ["Manual Login", "Google Login"])

    if login_method == "Manual Login":
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        if st.button("Login"):
            if username and password:
                st.session_state.is_logged_in = True
                st.session_state.user_role = st.selectbox("Select Role", ["Student", "Educator"])
            else:
                st.warning("Please enter both username and password.")
    else:
        st.write("Google Login Placeholder")
        if st.button("Login with Google"):
            st.session_state.is_logged_in = True
            st.session_state.user_role = st.selectbox("Select Role", ["Student", "Educator"])

def student_dashboard():
    st.header("Student Dashboard")
    selected = option_menu(
        menu_title=None,
        options=["Take Quiz", "Quiz History"],
        icons=["pencil", "clock"],
        orientation="horizontal",
    )

    if selected == "Take Quiz":
        st.subheader("Take Quiz")
        st.write("[Placeholder for quiz taking functionality]")
    elif selected == "Quiz History":
        st.subheader("Quiz History")
        st.write("[Placeholder for quiz history display]")

def educator_dashboard():
    st.header("Educator Dashboard")
    st.write("[Placeholder for all student analytics]")

def main():
    if not st.session_state.is_logged_in:
        login_page()
    else:
        if st.session_state.user_role == "Student":
            student_dashboard()
        elif st.session_state.user_role == "Educator":
            educator_dashboard()

if __name__ == "__main__":
    main()
