import streamlit as st
import requests

st.title("EduTutor AI")

menu = ["Login", "Dashboard", "Take Quiz", "Quiz History"]
choice = st.sidebar.selectbox("Menu", menu)

if choice == "Take Quiz":
    if st.button("Generate Quiz"):
        response = requests.get("http://localhost:8000/generate_quiz")
        st.write(response.json())
