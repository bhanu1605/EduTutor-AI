from fastapi import FastAPI
from langchain_ibm import WatsonxLLM
from dotenv import load_dotenv
import os

load_dotenv()

app = FastAPI()

llm = WatsonxLLM(
    model_id=os.getenv("WATSONX_MODEL_ID"),
    api_key=os.getenv("WATSONX_API_KEY"),
    url=os.getenv("WATSONX_ENDPOINT"),
    project_id=os.getenv("WATSONX_PROJECT_ID")
)

@app.get("/generate_quiz")
def generate_quiz():
    prompt = "Generate a 5-question quiz on Python basics."
    result = llm(prompt)
    return {"quiz": result}
