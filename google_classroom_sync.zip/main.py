import os
from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from starlette.middleware.sessions import SessionMiddleware
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SESSION_SECRET_KEY"))

GOOGLE_CLIENT_SECRETS_FILE = "client_secret.json"
SCOPES = ["https://www.googleapis.com/auth/classroom.courses.readonly"]
REDIRECT_URI = "http://localhost:8000/oauth2callback"


@app.get("/")
def home():
    return HTMLResponse('<a href="/login">Login with Google</a>')


@app.get("/login")
def login(request: Request):
    flow = Flow.from_client_secrets_file(
        GOOGLE_CLIENT_SECRETS_FILE,
        scopes=SCOPES,
        redirect_uri=REDIRECT_URI
    )
    auth_url, state = flow.authorization_url(
        access_type="offline",
        include_granted_scopes="true"
    )
    request.session['state'] = state
    return RedirectResponse(auth_url)


@app.get("/oauth2callback")
def oauth2callback(request: Request):
    state = request.session.get('state')
    flow = Flow.from_client_secrets_file(
        GOOGLE_CLIENT_SECRETS_FILE,
        scopes=SCOPES,
        state=state,
        redirect_uri=REDIRECT_URI
    )
    flow.fetch_token(authorization_response=str(request.url))

    credentials = flow.credentials

    service = build('classroom', 'v1', credentials=credentials)
    courses = service.courses().list().execute().get('courses', [])

    html = "<h1>Your Google Classroom Courses:</h1><ul>"
    for course in courses:
        html += f"<li>{course['name']}</li>"
    html += "</ul>"

    return HTMLResponse(html)
